# Atelier Draw (Android, Kotlin)
Abra a pasta no Android Studio (Koala+), aguarde o Gradle sync e use **Build > Build APK(s)**
(ou `gradle assembleDebug` — o wrapper .jar é gerado pelo Android Studio / `gradle wrapper`).
APK: app/build/outputs/apk/debug/app-debug.apk

Atalhos (teclado físico): Ctrl+Z desfazer · Ctrl+Shift+Z/Ctrl+Y refazer · Ctrl+S exportar PNG · Ctrl+N nova camada
P lápis · B caneta · M marcador · E borracha · I conta-gotas · G balde · S seleção · H mão · [ ] tamanho · + − zoom · 0 ajustar · Enter aplicar seleção
Gestos: 2 dedos = zoom, mover e girar a tela.
Pacotes: engine (desenho, camadas, histórico, preenchimento) · ui (roda de cores) · data (projeto/exportação).
