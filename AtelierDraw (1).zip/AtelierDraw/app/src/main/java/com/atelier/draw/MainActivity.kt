package com.atelier.draw

import android.app.ActivityManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.atelier.draw.data.Exporter
import com.atelier.draw.data.ProjectStore
import com.atelier.draw.engine.DrawingView
import com.atelier.draw.engine.Tool
import com.atelier.draw.ui.ColorWheelView
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var dv: DrawingView
    private lateinit var store: ProjectStore
    private val handler = Handler(Looper.getMainLooper())
    private val saveRun = Runnable { store.save(dv.layers, dv.active) }
    private val toolBtns = mutableMapOf<Tool, TextView>()
    private lateinit var sSize: SeekBar; private lateinit var sOpa: SeekBar; private lateinit var sPress: SeekBar
    private lateinit var swatch: View
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::importImage) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int = 10) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun chip(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { f() }
    }
    private fun seek(f: (Int, Boolean) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) = f(p, u)
        override fun onStartTrackingTouch(s: SeekBar) {}
        override fun onStopTrackingTouch(s: SeekBar) {}
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = ProjectStore(this)
        val saved = store.load()
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val size = saved?.first?.firstOrNull()?.bitmap?.width ?: if (am.largeMemoryClass >= 384) 2048 else 1536
        dv = DrawingView(this, size)
        saved?.let { dv.load(it.first, it.second) }
        dv.onChange = { handler.removeCallbacks(saveRun); handler.postDelayed(saveRun, 1500) }
        dv.onPick = { updateSwatch() }
        dv.onTool = { refreshTools(); syncSliders() }

        val root = FrameLayout(this)
        root.addView(dv, FrameLayout.LayoutParams(-1, -1))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(2), dp(6), dp(2)) }
        listOf(Tool.PENCIL to "Lápis", Tool.PEN to "Caneta", Tool.MARKER to "Marcador", Tool.ERASER to "Borracha",
            Tool.EYEDROPPER to "Conta-gotas", Tool.FILL to "Balde", Tool.SELECT to "Seleção", Tool.PAN to "Mão").forEach { (t, n) ->
            val v = chip(n) { dv.setTool(t) }; toolBtns[t] = v; row.addView(v)
        }
        row.addView(chip("↶") { dv.undo() }); row.addView(chip("↷") { dv.redo() })
        row.addView(chip("Camadas") { layersDialog() }); row.addView(chip("Imagem") { pickImage.launch("image/*") })
        row.addView(chip("⋮") { menuDialog() })
        val top = HorizontalScrollView(this).apply { setBackgroundColor(0xEE2A2A2E.toInt()); isHorizontalScrollBarEnabled = false; addView(row) }
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        fun labeled(t: String, s: SeekBar) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = t; setTextColor(0xFFAAAAAA.toInt()); textSize = 11f })
            addView(s)
        }
        sSize = SeekBar(this).apply { max = 300; setOnSeekBarChangeListener(seek { p, u -> if (u) dv.spec.size = max(1, p).toFloat() }) }
        sOpa = SeekBar(this).apply { max = 255; setOnSeekBarChangeListener(seek { p, u -> if (u) dv.spec.opacity = p }) }
        sPress = SeekBar(this).apply { max = 100; setOnSeekBarChangeListener(seek { p, u -> if (u) dv.spec.pressure = p / 100f }) }
        swatch = View(this).apply { setOnClickListener { colorDialog() } }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xEE2A2A2E.toInt()); setPadding(dp(12), dp(6), dp(12), dp(6))
            val lp = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) }
            addView(labeled("Tamanho", sSize), lp); addView(labeled("Opacidade", sOpa), lp); addView(labeled("Pressão", sPress), lp)
            addView(swatch, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        refreshTools(); syncSliders(); updateSwatch()
    }

    override fun onPause() { super.onPause(); handler.removeCallbacks(saveRun); dv.commitFloating(); store.save(dv.layers, dv.active) }

    private fun refreshTools() = toolBtns.forEach { (t, v) -> v.background = if (t == dv.tool) round(0xFF3D7BFF.toInt()) else null }
    private fun syncSliders() { val s = dv.spec; sSize.progress = s.size.toInt(); sOpa.progress = s.opacity; sPress.progress = (s.pressure * 100).toInt() }
    private fun updateSwatch() { swatch.background = GradientDrawable().apply { setColor(dv.color); setStroke(dp(2), Color.WHITE); cornerRadius = dp(22).toFloat() } }

    private fun colorDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val wheel = ColorWheelView(this).apply { setColor(dv.color) }
        val br = SeekBar(this).apply { max = 100; progress = (wheel.value * 100).toInt() }
        wheel.onColor = { dv.color = it; updateSwatch() }
        br.setOnSeekBarChangeListener(seek { p, u -> if (u) wheel.setValue(p / 100f) })
        box.addView(wheel, LinearLayout.LayoutParams(-1, dp(260))); box.addView(br)
        val cols = "#000000 #FFFFFF #8E8E93 #FF3B30 #FF9500 #FFCC00 #34C759 #00C7BE #30B0C7 #007AFF #5856D6 #AF52DE #FF2D55 #A2845E"
        val pal = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cols.split(" ").forEach { h ->
            val c = Color.parseColor(h)
            pal.addView(View(this).apply {
                background = round(c, 6)
                setOnClickListener { wheel.setColor(c); dv.color = c; updateSwatch() }
            }, LinearLayout.LayoutParams(0, dp(32), 1f).apply { setMargins(dp(2), dp(10), dp(2), dp(4)) })
        }
        box.addView(pal)
        AlertDialog.Builder(this).setView(box).setPositiveButton("OK", null).show()
    }

    private fun layersDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), 0) }
        AlertDialog.Builder(this).setTitle("Camadas").setView(box).setPositiveButton("OK", null).show()
        fun refresh() {
            box.removeAllViews()
            val ops = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun op(t: String, a: () -> Unit) = ops.addView(chip(t) { a(); refresh() })
            op("Nova") { dv.addLayer() }; op("Dup.") { dv.duplicateLayer() }; op("↑") { dv.moveLayer(1) }
            op("↓") { dv.moveLayer(-1) }; op("Fundir") { dv.mergeDown() }; op("Excluir") { dv.deleteLayer() }
            box.addView(HorizontalScrollView(this).apply { addView(ops) })
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            for (i in dv.layers.indices.reversed()) {
                val l = dv.layers[i]
                list.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    if (i == dv.active) background = round(0x553D7BFF, 8)
                    addView(CheckBox(context).apply { isChecked = l.visible; setOnCheckedChangeListener { _, c -> l.visible = c; dv.invalidate(); dv.onChange?.invoke() } })
                    addView(TextView(context).apply {
                        text = l.name; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(8), dp(12), dp(8), dp(12))
                        setOnClickListener { dv.selectLayer(i); refresh() }
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                })
            }
            box.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, dp(220)))
            box.addView(TextView(this).apply { text = "Opacidade da camada"; setTextColor(0xFFAAAAAA.toInt()); textSize = 11f })
            box.addView(SeekBar(this).apply {
                max = 255; progress = dv.layers[dv.active].opacity
                setOnSeekBarChangeListener(seek { p, u -> if (u) { dv.layers[dv.active].opacity = p; dv.invalidate(); dv.onChange?.invoke() } })
            })
        }
        refresh()
    }

    private fun menuDialog() {
        val items = arrayOf("Ajustar à tela", "Girar tela 90°", "Seleção: aumentar", "Seleção: diminuir", "Seleção: girar 15°",
            "Aplicar seleção", "Limpar camada", "Exportar PNG", "Exportar JPG", "Novo projeto")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> dv.fitView(); 1 -> dv.rotateView90()
                2 -> dv.transformFloating(1.1f, 0f); 3 -> dv.transformFloating(0.9f, 0f); 4 -> dv.transformFloating(1f, 15f)
                5 -> dv.commitFloating(); 6 -> dv.clearLayer()
                7 -> export(true); 8 -> export(false)
                9 -> AlertDialog.Builder(this).setMessage("Apagar o projeto atual?").setPositiveButton("Apagar") { _, _ -> dv.reset() }.setNegativeButton("Cancelar", null).show()
            }
        }.show()
    }

    private fun export(png: Boolean) {
        dv.commitFloating()
        val bmp = dv.composite(!png)
        Thread {
            val uri = Exporter.save(this, bmp, png); bmp.recycle()
            runOnUiThread { Toast.makeText(this, if (uri != null) "Imagem exportada" else "Falha ao exportar", Toast.LENGTH_LONG).show() }
        }.start()
    }

    private fun importImage(uri: Uri) {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1; while (max(o.outWidth, o.outHeight) / s > 2048) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp != null) dv.importBitmap(bmp)
        } catch (e: Exception) { Toast.makeText(this, "Não foi possível importar", Toast.LENGTH_SHORT).show() }
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        val ctrl = e.isCtrlPressed
        fun size(d: Float) { dv.spec.size = (dv.spec.size + d).coerceIn(1f, 300f); syncSliders() }
        when {
            ctrl && k == KeyEvent.KEYCODE_Z -> if (e.isShiftPressed) dv.redo() else dv.undo()
            ctrl && k == KeyEvent.KEYCODE_Y -> dv.redo()
            ctrl && k == KeyEvent.KEYCODE_S -> export(true)
            ctrl && k == KeyEvent.KEYCODE_N -> dv.addLayer()
            k == KeyEvent.KEYCODE_P -> dv.setTool(Tool.PENCIL)
            k == KeyEvent.KEYCODE_B -> dv.setTool(Tool.PEN)
            k == KeyEvent.KEYCODE_M -> dv.setTool(Tool.MARKER)
            k == KeyEvent.KEYCODE_E -> dv.setTool(Tool.ERASER)
            k == KeyEvent.KEYCODE_I -> dv.setTool(Tool.EYEDROPPER)
            k == KeyEvent.KEYCODE_G -> dv.setTool(Tool.FILL)
            k == KeyEvent.KEYCODE_S -> dv.setTool(Tool.SELECT)
            k == KeyEvent.KEYCODE_H -> dv.setTool(Tool.PAN)
            k == KeyEvent.KEYCODE_LEFT_BRACKET -> size(-4f)
            k == KeyEvent.KEYCODE_RIGHT_BRACKET -> size(4f)
            k == KeyEvent.KEYCODE_PLUS || k == KeyEvent.KEYCODE_EQUALS -> dv.zoomBy(1.25f)
            k == KeyEvent.KEYCODE_MINUS -> dv.zoomBy(0.8f)
            k == KeyEvent.KEYCODE_0 -> dv.fitView()
            k == KeyEvent.KEYCODE_ENTER -> dv.commitFloating()
            else -> return super.onKeyDown(k, e)
        }
        return true
    }
}
