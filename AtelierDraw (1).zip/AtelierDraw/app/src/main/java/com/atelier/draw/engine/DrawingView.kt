package com.atelier.draw.engine

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class DrawingView(ctx: Context, val ds: Int) : View(ctx) {
    val layers = mutableListOf<Layer>()
    var active = 0
        private set
    var tool = Tool.PEN
        private set
    var brushTool = Tool.PEN
        private set
    var color = Color.BLACK
    val specs = mapOf(
        Tool.PENCIL to BrushSpec(4f, 200, 0.8f, Paint.Cap.ROUND),
        Tool.PEN to BrushSpec(10f, 255, 0.6f, Paint.Cap.ROUND),
        Tool.MARKER to BrushSpec(40f, 110, 0f, Paint.Cap.SQUARE),
        Tool.ERASER to BrushSpec(40f, 255, 0.5f, Paint.Cap.ROUND))
    val spec get() = specs.getValue(brushTool)
    var onChange: (() -> Unit)? = null
    var onPick: ((Int) -> Unit)? = null
    var onTool: (() -> Unit)? = null

    private val m = Matrix(); private val inv = Matrix()
    private val strokeBmp = Bitmap.createBitmap(ds, ds, Bitmap.Config.ARGB_8888)
    private val strokeCanvas = Canvas(strokeBmp)
    private val lp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val paper = Paint().apply { color = Color.WHITE }
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val strokePaint = Paint()
    private val outline = Paint().apply { style = Paint.Style.STROKE; color = 0xFF3D7BFF.toInt() }
    private val clearP = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val pts = FloatArray(2)
    private var fitted = false
    private var stroking = false
    private var lx = 0f; private var ly = 0f
    private var multi = false; private var pinchInit = false
    private var pcx = 0f; private var pcy = 0f; private var pd = 1f; private var pa = 0f
    private var pickBmp: Bitmap? = null
    private var selRect: RectF? = null; private var sx = 0f; private var sy = 0f
    private var floatBmp: Bitmap? = null; private val fm = Matrix(); private var dragMove = false

    private class Snap(val layer: Layer, val bmp: Bitmap)
    private val undoS = ArrayDeque<Snap>(); private val redoS = ArrayDeque<Snap>()

    init { layers.add(Layer("Camada 1", newBmp())) }
    private fun newBmp() = Bitmap.createBitmap(ds, ds, Bitmap.Config.ARGB_8888)
    private fun changed() { invalidate(); onChange?.invoke() }

    // ---------- vista (zoom / rotação) ----------
    private fun upd() { m.invert(inv); invalidate() }
    private fun scale(): Float { val v = FloatArray(9); m.getValues(v); return hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y]) }
    fun fitView() {
        if (width == 0) return
        val s = min(width, height) * 0.95f / ds
        m.reset(); m.postScale(s, s); m.postTranslate((width - ds * s) / 2, (height - ds * s) / 2); upd()
    }
    fun zoomBy(f: Float) { m.postScale(f, f, width / 2f, height / 2f); upd() }
    fun rotateView90() { m.postRotate(90f, width / 2f, height / 2f); upd() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { if (!fitted && w > 0) { fitted = true; fitView() } }
    private fun doc(x: Float, y: Float): FloatArray { pts[0] = x; pts[1] = y; inv.mapPoints(pts); return pts }

    // ---------- ferramentas ----------
    fun setTool(t: Tool) {
        commitFloating(); tool = t
        if (specs.containsKey(t)) brushTool = t
        onTool?.invoke()
    }

    // ---------- desfazer / refazer (por camada) ----------
    private fun pushUndo(l: Layer) {
        undoS.addLast(Snap(l, l.bitmap.copy(Bitmap.Config.ARGB_8888, true)))
        if (undoS.size > 15) undoS.removeFirst().bmp.recycle()
        redoS.forEach { it.bmp.recycle() }; redoS.clear()
    }
    private fun swapFrom(src: ArrayDeque<Snap>, dst: ArrayDeque<Snap>) {
        floatBmp = null; selRect = null
        while (src.isNotEmpty()) {
            val s = src.removeLast()
            if (s.layer !in layers) { s.bmp.recycle(); continue }
            val cur = s.layer.bitmap; s.layer.bitmap = s.bmp; dst.addLast(Snap(s.layer, cur)); break
        }
        changed()
    }
    fun undo() = swapFrom(undoS, redoS)
    fun redo() = swapFrom(redoS, undoS)

    // ---------- camadas ----------
    fun selectLayer(i: Int) { commitFloating(); active = i.coerceIn(0, layers.lastIndex); invalidate() }
    fun addLayer() { commitFloating(); layers.add(active + 1, Layer("Camada ${layers.size + 1}", newBmp())); active++; changed() }
    fun duplicateLayer() {
        commitFloating(); val l = layers[active]
        layers.add(active + 1, Layer(l.name + " cópia", l.bitmap.copy(Bitmap.Config.ARGB_8888, true), l.visible, l.opacity)); active++; changed()
    }
    fun deleteLayer() {
        commitFloating()
        if (layers.size == 1) { pushUndo(layers[0]); layers[0].bitmap.eraseColor(0) } else { layers.removeAt(active); active = min(active, layers.lastIndex) }
        changed()
    }
    fun moveLayer(d: Int) {
        val j = active + d; if (j !in layers.indices) return
        commitFloating(); val t = layers[active]; layers[active] = layers[j]; layers[j] = t; active = j; changed()
    }
    fun mergeDown() {
        if (active == 0) return
        commitFloating(); val up = layers[active]; val lo = layers[active - 1]
        pushUndo(lo); lo.canvas.drawBitmap(up.bitmap, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = up.opacity })
        layers.removeAt(active); active--; changed()
    }
    fun clearLayer() { pushUndo(layers[active]); layers[active].bitmap.eraseColor(0); changed() }
    fun reset() { layers.clear(); layers.add(Layer("Camada 1", newBmp())); active = 0; undoS.clear(); redoS.clear(); floatBmp = null; changed() }
    fun load(ls: List<Layer>, act: Int) { layers.clear(); layers.addAll(ls); active = act.coerceIn(0, layers.lastIndex); undoS.clear(); redoS.clear(); invalidate() }

    fun composite(white: Boolean): Bitmap {
        val b = newBmp(); val c = Canvas(b); if (white) c.drawColor(Color.WHITE)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        for (l in layers) if (l.visible) { p.alpha = l.opacity; c.drawBitmap(l.bitmap, 0f, 0f, p) }
        return b
    }

    // ---------- seleção retangular / transformação / importação ----------
    fun commitFloating() {
        val fb = floatBmp ?: return
        layers[active].canvas.drawBitmap(fb, fm, lp); floatBmp = null; changed()
    }
    fun transformFloating(s: Float, deg: Float) {
        val fb = floatBmp ?: return
        val p = floatArrayOf(fb.width / 2f, fb.height / 2f); fm.mapPoints(p)
        fm.postScale(s, s, p[0], p[1]); fm.postRotate(deg, p[0], p[1]); invalidate()
    }
    fun importBitmap(b: Bitmap) {
        addLayer(); layers[active].name = "Imagem"; setTool(Tool.SELECT)
        val s = min(ds * 0.8f / b.width, ds * 0.8f / b.height)
        fm.reset(); fm.postScale(s, s); fm.postTranslate((ds - b.width * s) / 2, (ds - b.height * s) / 2)
        floatBmp = b; invalidate()
    }
    private fun lift(r: RectF) {
        r.intersect(0f, 0f, ds.toFloat(), ds.toFloat())
        val ri = Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt())
        if (ri.width() < 4 || ri.height() < 4) return
        val l = layers[active]; pushUndo(l)
        floatBmp = Bitmap.createBitmap(l.bitmap, ri.left, ri.top, ri.width(), ri.height())
        l.canvas.drawRect(ri, clearP)
        fm.reset(); fm.postTranslate(ri.left.toFloat(), ri.top.toFloat()); invalidate()
    }

    // ---------- toque ----------
    private fun isStylus(e: MotionEvent) = e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
    private fun press(e: MotionEvent) = if (isStylus(e)) e.pressure.coerceIn(0.05f, 1f) else 1f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { multi = false; pinchInit = false; down(e.x, e.y, press(e)) }
            MotionEvent.ACTION_POINTER_DOWN -> { if (!multi) { cancelGesture(); multi = true }; pinchInit = false }
            MotionEvent.ACTION_POINTER_UP -> pinchInit = false
            MotionEvent.ACTION_MOVE -> if (multi) { if (e.pointerCount >= 2) pinch(e) } else {
                for (i in 0 until e.historySize)
                    move(e.getHistoricalX(i), e.getHistoricalY(i), if (isStylus(e)) e.getHistoricalPressure(i).coerceIn(0.05f, 1f) else 1f)
                move(e.x, e.y, press(e))
            }
            MotionEvent.ACTION_UP -> { if (!multi) up(); multi = false }
            MotionEvent.ACTION_CANCEL -> { cancelGesture(); multi = false }
        }
        return true
    }

    private fun pinch(e: MotionEvent) {
        val x0 = e.getX(0); val y0 = e.getY(0); val x1 = e.getX(1); val y1 = e.getY(1)
        val cx = (x0 + x1) / 2; val cy = (y0 + y1) / 2; val d = max(1f, hypot(x1 - x0, y1 - y0))
        val a = Math.toDegrees(atan2((y1 - y0).toDouble(), (x1 - x0).toDouble())).toFloat()
        if (pinchInit) {
            m.postTranslate(cx - pcx, cy - pcy)
            val s = d / pd; if (scale() * s in 0.05f..32f) m.postScale(s, s, cx, cy)
            m.postRotate(a - pa, cx, cy); upd()
        }
        pcx = cx; pcy = cy; pd = d; pa = a; pinchInit = true
    }

    private fun cancelGesture() {
        if (stroking) { stroking = false; strokeBmp.eraseColor(0); undoS.removeLastOrNull()?.bmp?.recycle() }
        selRect = null; dragMove = false; pickBmp?.recycle(); pickBmp = null; invalidate()
    }

    private fun down(x: Float, y: Float, p: Float) {
        val d = doc(x, y); val dx = d[0]; val dy = d[1]; val layer = layers[active]
        when (tool) {
            Tool.PENCIL, Tool.PEN, Tool.MARKER, Tool.ERASER -> {
                if (!layer.visible) return
                pushUndo(layer); stroking = true; lx = dx; ly = dy; seg(dx, dy, p); invalidate()
            }
            Tool.EYEDROPPER -> { pickBmp = composite(true); pick(dx, dy) }
            Tool.FILL -> { pushUndo(layer); FloodFill.fill(layer.bitmap, dx.toInt(), dy.toInt(), color or 0xFF000000.toInt()); changed() }
            Tool.SELECT -> selDown(dx, dy)
            Tool.PAN -> { lx = x; ly = y }
        }
    }

    private fun move(x: Float, y: Float, p: Float) {
        when (tool) {
            Tool.PAN -> { m.postTranslate(x - lx, y - ly); lx = x; ly = y; upd() }
            Tool.PENCIL, Tool.PEN, Tool.MARKER, Tool.ERASER -> if (stroking) { val d = doc(x, y); seg(d[0], d[1], p); invalidate() }
            Tool.EYEDROPPER -> { val d = doc(x, y); pick(d[0], d[1]) }
            Tool.SELECT -> { val d = doc(x, y); selMove(d[0], d[1]) }
            else -> {}
        }
    }

    private fun up() {
        when (tool) {
            Tool.PENCIL, Tool.PEN, Tool.MARKER, Tool.ERASER -> endStroke()
            Tool.EYEDROPPER -> { pickBmp?.recycle(); pickBmp = null }
            Tool.SELECT -> selUp()
            else -> {}
        }
    }

    private fun pick(x: Float, y: Float) {
        val b = pickBmp ?: return
        if (x.toInt() in 0 until ds && y.toInt() in 0 until ds) { color = b.getPixel(x.toInt(), y.toInt()); onPick?.invoke(color) }
    }

    private fun seg(x: Float, y: Float, p: Float) {
        val s = spec
        sp.color = (if (tool == Tool.ERASER) Color.BLACK else color) or 0xFF000000.toInt()
        sp.strokeWidth = max(0.5f, s.size * (1f - s.pressure + s.pressure * p)); sp.strokeCap = s.cap
        if (x == lx && y == ly) strokeCanvas.drawPoint(x, y, sp) else strokeCanvas.drawLine(lx, ly, x, y, sp)
        lx = x; ly = y
    }

    private fun endStroke() {
        if (!stroking) return
        val pp = Paint(); pp.alpha = spec.opacity
        if (tool == Tool.ERASER) pp.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        layers[active].canvas.drawBitmap(strokeBmp, 0f, 0f, pp)
        strokeBmp.eraseColor(0); stroking = false; changed()
    }

    private fun selDown(x: Float, y: Float) {
        val fb = floatBmp
        if (fb != null) {
            val i = Matrix(); fm.invert(i); val q = floatArrayOf(x, y); i.mapPoints(q)
            if (q[0] in 0f..fb.width.toFloat() && q[1] in 0f..fb.height.toFloat()) { dragMove = true; lx = x; ly = y; return }
            commitFloating()
        }
        sx = x; sy = y; selRect = RectF(x, y, x, y); dragMove = false
    }
    private fun selMove(x: Float, y: Float) {
        if (dragMove) { fm.postTranslate(x - lx, y - ly); lx = x; ly = y } else selRect?.set(min(sx, x), min(sy, y), max(sx, x), max(sy, y))
        invalidate()
    }
    private fun selUp() {
        if (dragMove) { dragMove = false; return }
        val r = selRect ?: return; selRect = null; lift(r); invalidate()
    }

    // ---------- desenho ----------
    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF1C1C1E.toInt())
        c.save(); c.concat(m)
        val d = ds.toFloat()
        c.drawRect(0f, 0f, d, d, paper)
        val lw = 2f / scale(); outline.strokeWidth = lw
        layers.forEachIndexed { i, l ->
            if (!l.visible) return@forEachIndexed
            lp.alpha = l.opacity
            if (i == active && stroking) {
                c.saveLayer(0f, 0f, d, d, lp)
                c.drawBitmap(l.bitmap, 0f, 0f, null)
                strokePaint.alpha = spec.opacity
                strokePaint.xfermode = if (tool == Tool.ERASER) PorterDuffXfermode(PorterDuff.Mode.DST_OUT) else null
                c.drawBitmap(strokeBmp, 0f, 0f, strokePaint)
                c.restore()
            } else c.drawBitmap(l.bitmap, 0f, 0f, lp)
            val fb = floatBmp
            if (i == active && fb != null) {
                lp.alpha = 255; c.save(); c.concat(fm); c.drawBitmap(fb, 0f, 0f, lp)
                c.drawRect(0f, 0f, fb.width.toFloat(), fb.height.toFloat(), outline); c.restore()
            }
        }
        selRect?.let { outline.pathEffect = DashPathEffect(floatArrayOf(10 * lw, 6 * lw), 0f); c.drawRect(it, outline); outline.pathEffect = null }
        c.restore()
    }
}
