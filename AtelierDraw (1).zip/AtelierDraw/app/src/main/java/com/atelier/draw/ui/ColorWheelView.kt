package com.atelier.draw.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Roda de cores (matiz + saturação). O brilho é controlado por [setValue]. */
class ColorWheelView(ctx: Context) : View(ctx) {
    var hue = 0f; var sat = 0f; var value = 1f
    var onColor: ((Int) -> Unit)? = null
    private var cx = 0f; private var cy = 0f; private var r = 0f
    private val wp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ind = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.WHITE }

    fun current() = Color.HSVToColor(floatArrayOf(hue, sat, value))
    fun setColor(c: Int) { val h = FloatArray(3); Color.colorToHSV(c, h); hue = h[0]; sat = h[1]; value = h[2]; invalidate() }
    fun setValue(v: Float) { value = v; invalidate(); onColor?.invoke(current()) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = min(w, h) / 2f - 8f
        val hues = IntArray(361) { Color.HSVToColor(floatArrayOf(it.toFloat(), 1f, 1f)) }
        wp.shader = ComposeShader(SweepGradient(cx, cy, hues, null),
            RadialGradient(cx, cy, r, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP), PorterDuff.Mode.SRC_OVER)
    }
    override fun onDraw(c: Canvas) {
        c.drawCircle(cx, cy, r, wp)
        shade.color = Color.argb(((1f - value) * 255).toInt(), 0, 0, 0); c.drawCircle(cx, cy, r, shade)
        val a = Math.toRadians(hue.toDouble())
        c.drawCircle(cx + (cos(a) * sat * r).toFloat(), cy + (sin(a) * sat * r).toFloat(), 14f, ind)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val dx = e.x - cx; val dy = e.y - cy
        hue = ((Math.toDegrees(atan2(dy, dx).toDouble()) + 360) % 360).toFloat()
        sat = min(1f, hypot(dx, dy) / r)
        invalidate(); onColor?.invoke(current()); return true
    }
}
