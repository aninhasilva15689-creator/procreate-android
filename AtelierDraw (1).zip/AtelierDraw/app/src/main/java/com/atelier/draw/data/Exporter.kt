package com.atelier.draw.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object Exporter {
    fun save(ctx: Context, bmp: Bitmap, png: Boolean): Uri? = try {
        val name = "atelier_${System.currentTimeMillis()}." + if (png) "png" else "jpg"
        val fmt = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AtelierDraw")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            uri?.also { u -> ctx.contentResolver.openOutputStream(u)?.use { bmp.compress(fmt, 95, it) } }
        } else {
            val d = File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "AtelierDraw").apply { mkdirs() }
            val f = File(d, name); f.outputStream().use { bmp.compress(fmt, 95, it) }; Uri.fromFile(f)
        }
    } catch (_: Exception) { null }
}
