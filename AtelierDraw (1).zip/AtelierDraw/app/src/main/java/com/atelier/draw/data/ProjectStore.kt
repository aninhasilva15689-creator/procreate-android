package com.atelier.draw.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.atelier.draw.engine.Layer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** Salvamento automático: cada camada vira um PNG + meta.json (escrita atômica via arquivo temporário). */
class ProjectStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "project").apply { mkdirs() }
    private val io = Executors.newSingleThreadExecutor()
    private class Item(val name: String, val visible: Boolean, val opacity: Int, val bmp: Bitmap)

    fun save(layers: List<Layer>, active: Int) {
        val items = layers.map { Item(it.name, it.visible, it.opacity, it.bitmap) }
        io.execute {
            try {
                val arr = JSONArray()
                items.forEachIndexed { i, it ->
                    val f = File(dir, "layer_$i.png"); val t = File(dir, "layer_$i.png.tmp")
                    t.outputStream().use { o -> it.bmp.compress(Bitmap.CompressFormat.PNG, 100, o) }; t.renameTo(f)
                    arr.put(JSONObject().put("name", it.name).put("visible", it.visible).put("opacity", it.opacity).put("file", f.name))
                }
                val t = File(dir, "meta.json.tmp"); t.writeText(JSONObject().put("active", active).put("layers", arr).toString())
                t.renameTo(File(dir, "meta.json"))
                dir.listFiles()?.filter { it.name.startsWith("layer_") && it.name.endsWith(".png") && it.name.removePrefix("layer_").removeSuffix(".png").toIntOrNull()?.let { n -> n >= items.size } == true }?.forEach { it.delete() }
            } catch (_: Exception) {}
        }
    }

    fun load(): Pair<List<Layer>, Int>? = try {
        val meta = File(dir, "meta.json")
        if (!meta.exists()) null else {
            val j = JSONObject(meta.readText()); val arr = j.getJSONArray("layers")
            val o = BitmapFactory.Options().apply { inMutable = true; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val ls = (0 until arr.length()).map {
                val l = arr.getJSONObject(it)
                Layer(l.getString("name"), BitmapFactory.decodeFile(File(dir, l.getString("file")).path, o)!!, l.getBoolean("visible"), l.getInt("opacity"))
            }
            if (ls.isEmpty()) null else Pair(ls, j.getInt("active"))
        }
    } catch (_: Exception) { null }
}
