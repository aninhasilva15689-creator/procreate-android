package com.atelier.draw.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

enum class Tool { PENCIL, PEN, MARKER, ERASER, EYEDROPPER, FILL, SELECT, PAN }

/** Pincel personalizável: tamanho (px do documento), opacidade 0..255, sensibilidade à pressão 0..1. */
class BrushSpec(var size: Float, var opacity: Int, var pressure: Float, val cap: Paint.Cap)

class Layer(var name: String, b: Bitmap, var visible: Boolean = true, var opacity: Int = 255) {
    var bitmap: Bitmap = b
        set(v) { field = v; canvas = Canvas(v) }
    var canvas: Canvas = Canvas(b)
        private set
}
