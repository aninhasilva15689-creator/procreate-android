package com.atelier.draw.engine

import android.graphics.Bitmap
import kotlin.math.abs

object FloodFill {
    private fun match(a: Int, b: Int, t: Int) =
        abs((a ushr 24) - (b ushr 24)) <= t && abs(((a shr 16) and 255) - ((b shr 16) and 255)) <= t &&
        abs(((a shr 8) and 255) - ((b shr 8) and 255)) <= t && abs((a and 255) - (b and 255)) <= t

    fun fill(bmp: Bitmap, x: Int, y: Int, color: Int, tol: Int = 24) {
        val w = bmp.width; val h = bmp.height
        if (x !in 0 until w || y !in 0 until h) return
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val target = px[y * w + x]
        if (target == color) return
        val seen = BooleanArray(w * h)
        val stack = ArrayDeque<Int>(); stack.add(y * w + x)
        while (stack.isNotEmpty()) {
            val p = stack.removeLast(); val cy = p / w
            if (seen[p] || !match(px[p], target, tol)) continue
            var l = p % w; var r = l
            while (l > 0 && !seen[cy * w + l - 1] && match(px[cy * w + l - 1], target, tol)) l--
            while (r < w - 1 && !seen[cy * w + r + 1] && match(px[cy * w + r + 1], target, tol)) r++
            var up = false; var dn = false
            for (i in l..r) {
                val idx = cy * w + i; seen[idx] = true; px[idx] = color
                if (cy > 0) { val m = !seen[idx - w] && match(px[idx - w], target, tol); if (m && !up) stack.add(idx - w); up = m }
                if (cy < h - 1) { val m = !seen[idx + w] && match(px[idx + w], target, tol); if (m && !dn) stack.add(idx + w); dn = m }
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }
}
